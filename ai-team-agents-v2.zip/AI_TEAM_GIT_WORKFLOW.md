# AI Team Git, Review, Version, and Release Workflow

## Verdict

The original agents were not safe to use with the requested branching model without changes:

- the Dev Team created branches from `main` rather than `development`
- the Producer owned merges to `main`, conflicting with a Lead Developer release PR and independent DevOps approval
- QA had no explicit release-candidate gate
- no agent owned configuration-driven reviewers, semantic version cascading, GitHub Actions recovery, idempotent tag/deployment handling, or back-merging hotfixes

The revised model assigns one owner per gate.

## Role Ownership

| Stage | Owner | Output |
|---|---|---|
| Business definition | Business Analyst | Requirement IDs and acceptance criteria |
| Sprint scope | Producer | Approved sprint plan |
| Product implementation | Dev Team | `feature/* → development` PR |
| Product verification | QA | Feature/integration/release sign-off |
| Repository/CI/release governance | DevOps | Review routing, checks, version, merge, tag, deploy |
| Production release PR author | Lead Developer | `development → main` PR |
| Production approval and merge | Independent configured Release Manager/DevOps reviewer | Approved and merged release |

## Normal Flow

```text
Business request
  ↓
Business Analyst specification: READY
  ↓
Producer sprint plan
  ↓
Dev branch from development
  ↓
feature/* → development PR
  ↓
Configured reviewers + latest-SHA CI + QA gate
  ↓
Merge to development
  ↓
Integration/regression QA PASS
  ↓
release/version-X.Y.Z → development (atomic version cascade)
  ↓
Lead Developer opens development → main
  ↓
One independent configured approval + all required checks
  ↓
DevOps merge → tag exact main SHA → GitHub Release → protected deployment
  ↓
Health verification and release record
```

## Why the Separate Version-Cascade PR Exists

Direct commits to protected `development` should not be required merely to prepare a release. The version branch provides reviewable, atomic updates across all configured version files. Once it merges, the final PR still satisfies the required `development → main` route and already contains the correct version.

## Failure Ownership

| Failure | Owner |
|---|---|
| workflow YAML, permissions, action, cache, Docker, infrastructure, tag, deployment, version sync | DevOps |
| application build caused by product code, failed unit/E2E assertion, product behaviour | Dev Team |
| acceptance criteria mismatch | Business Analyst + Producer |
| discovered product defect | QA files; Dev Team fixes; QA verifies |
| transient runner/network issue | DevOps reruns failed jobs within retry policy |

## Required Repository Setup

1. Copy `ai-team-governance.example.yml` to `.github/ai-team-governance.yml` and replace placeholders.
2. Create/validate `.github/CODEOWNERS`.
3. Protect `development` and `main` with required PRs, approvals, status checks, conversation resolution, and no force-push/direct-push.
4. Configure a protected `production` environment with an independent required reviewer.
5. Use separate GitHub identities/teams for Lead Developer PR authorship and release approval when independent approval is required.
6. Ensure version/tag jobs fetch full Git history and run with minimal permissions.
7. Use release concurrency to prevent overlapping version/tag/deployment runs.

## Merge Policy

The examples retain regular merge commits to match the existing team policy. Change `merge_method` in governance configuration only after an explicit repository-level decision; all agents must follow the same configured method.
